namespace cliente.Models{

    class Cliente{

        public int Id { get; set; }
        public string Nome{ get; set; } = "";
        public int Cpf { get; set; }

        public int Telefone { get; set; }

        public string Pedido {get; set;} = "";
        public string Endere�o { get; set; } = "";

        public string Status { get; set; } = "";

        public DateTime Data { get; set; }

    }


}