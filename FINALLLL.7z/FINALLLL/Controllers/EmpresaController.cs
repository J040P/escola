using Microsoft.AspNetCore.Mvc;
using empresa.Models;

namespace empresa.Controllers
{
    public class EmpresaController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var empresas = new List<Empresa>{
                new Empresa{
                    Id = 1,
                    Nome = "Fornecedor Lauren",
                    Taxa = 1.4m,
                    Endereço = "Rua david tows 890 sob 1",
                    Cnpj = 1234647076,
                    Fiscal = "MEI",
                    Data = DateTime.Now
                },
                new Empresa{
                    Id = 2,
                    Nome = "Fornecedor Thiago",
                    Taxa = 1.5m,
                    Endereço = "Rua david tows 890 sob 2",
                    Cnpj = 1234647076,
                    Fiscal = "SA",
                    Data = DateTime.Now
                },
                new Empresa{
                    Id = 3,
                    Nome = "Fornecedor Marcelo",
                    Taxa = 3.5m,
                    Endereço = "Rua david tows 890 sob 3",
                    Cnpj = 1234647076,
                    Fiscal = "MEI",
                    Data = DateTime.Now
                }
            };


            return View(empresas);
        }
    }
}
