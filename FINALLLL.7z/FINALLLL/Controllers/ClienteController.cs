using Microsoft.AspNetCore.Mvc;
using cliente.Models;

namespace cliente.Controllers
{
    public class ClienteController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var clientes = new List<Cliente>{
                new Cliente{
                    Id = 1,
                    Nome = "Fernando",
                    Cpf = 132472606,
                    Telefone = 54745289,
                    Pedido = "326#",
                    Endereço = "rua Leopoudo Pereira 348",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 1,
                    Nome = "Thiago",
                    Cpf = 132472606,
                    Telefone = 54745289,
                    Pedido = "336#",
                    Endereço = "rua Leopoudo Pereira 398",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 1,
                    Nome = "Fernado",
                    Cpf = 132472606,
                    Telefone = 54745289,
                    Pedido = "126#",
                    Endereço = "rua Leopoudo Pereira 318",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                }
            };


            return View(clientes);
        }
    }
}
