using Microsoft.AspNetCore.Mvc;
using produto.Models;

namespace produto.Controllers
{
    public class ClienteController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var clientes = new List<Cliente>{
                new Cliente{
                    Id = 1,
                    Nome = "Produto X",
                    Cpf = 132472606,
                    Telefone = 54745289,
                    Pedido = "O melhor produto que você nunca teve.",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 1,
                    Nome = "Produto X",
                    Cpf = 132472606,
                    Telefone = 54745289,
                    Pedido = "O melhor produto que você nunca teve.",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 1,
                    Nome = "Produto X",
                    Cpf = 132472606,
                    Telefone = 54745289,
                    Pedido = "O melhor produto que você nunca teve.",
                    Status = "ENVIADO",
                    Data = DateTime.Now
            };


            return View(clientes);
        }
    }
}
